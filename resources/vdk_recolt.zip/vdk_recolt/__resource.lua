dependency 'vdk_inventory'

server_scripts {
	'config.lua',
	'vdk_recolt_server.lua'
}

client_script {
	'vdkrec.lua'
}