ASData = {
	weather = "CLEAR",
	blackout = false,
	wind = { speed = 0.0, direction = 0.0 },
	time = { h = 12, m = 0, s = 0, frozen = false, rates = {day = 1.0, night = 1.0} },
	traffic = 0.9999999,
	crowd = 0.9999999
}