client_script "mairie_client.lua"
server_script "mairie_server.lua"