client_script "frfuel.net.dll"
server_script "pay.lua"
