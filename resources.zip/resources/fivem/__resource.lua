resource_type 'gametype' { name = 'Freeroam' }

client_script 'fivem_client.lua'