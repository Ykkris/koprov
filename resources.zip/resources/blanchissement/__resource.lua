
------
-- Blanchissement by KoproV.fr
-- Verstion: v0.0.1
------

-- Manifest Version
resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'

-- Client Scripts
client_script 'client/client_main_blanchissement.lua'

-- Server Scripts
server_script 'server/server_main_blanchissement.lua'
