# Changelog
The information about the changes can be found below. 

## v2.1 (17-4-2017)  
#### Features
- Changed the location cause the old one got issues.
- Added a colour to the blip.
- Added function when player spawn on server, it set vehicle available in the garage.
- Changed in that when before the player selected an action, he was teleported into the marker, now not.

## v2 (16-4-2017)  
#### Features
- Changed veshop.lua and veshop_s.lua because the mod does not include the function of saving the license plate in the database.
- The purchased vehicle is no longer stored in the "personalvehicle" table but in a specific one.
- Added (obviously copyed/pasted and little changed) afunction to update or add vehicle if player had one or not (function from vehshop).

- Added new table in the database.
- Added function that check if the player'vehicule is out or in the garage and therefor do the stuff to spawn or not.
- Added function that checks if the vehicle the player wants to store is the owner, if not nothing happen.
- Added function that checks is the spawn-vehicle-area is clear or not.


## v1 (14-4-2017)  
#### Features
- Spawn your personnal vehicle, if you owned one.
- Store your personnal vehicule
