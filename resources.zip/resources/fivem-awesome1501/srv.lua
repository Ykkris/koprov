RegisterServerEvent('yepThatsMe')

AddEventHandler('yepThatsMe', function(id, name, tab)
	print('ytm ', id, name, tab.a)
end)