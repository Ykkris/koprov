client_script "selcloth_client.lua"
