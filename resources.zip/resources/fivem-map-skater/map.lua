spawnpoint 'a_m_y_skater_01' { x = 295.34182, y = -1448.37829, z = 29.96660 }

--