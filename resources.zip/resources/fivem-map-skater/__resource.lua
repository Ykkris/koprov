resource_type 'map' { gameTypes = { es_freeroam = true } }

map 'map.lua'
