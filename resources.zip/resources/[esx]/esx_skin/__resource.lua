description 'ESX Skin'

server_script 'server/main.lua'
client_script 'client/main.lua'
