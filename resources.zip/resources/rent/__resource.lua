client_script {
  "gui.lua",
  "cl_rent.lua"
}
server_script "sv_rent.lua"
