client_script {
  "gui.lua",
  "cl_pechegarage.lua"
}
server_script "sv_pechegarage.lua"
