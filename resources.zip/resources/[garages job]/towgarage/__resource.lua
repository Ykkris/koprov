client_script {
  "gui.lua",
  "c_towgarage.lua"
}
server_script "s_towgarage.lua"