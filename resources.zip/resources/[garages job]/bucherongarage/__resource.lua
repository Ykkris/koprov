client_script {
  "gui.lua",
  "cl_buchgarage.lua"
}
server_script "sv_buchgarage.lua"
