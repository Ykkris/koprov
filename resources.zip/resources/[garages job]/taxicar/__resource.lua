client_script {
  "gui.lua",
  "cl_taximanc.lua"
}
server_script "sv_taximanc.lua"
