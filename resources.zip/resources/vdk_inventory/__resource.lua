server_scripts {
	'config.lua',
	'server.lua'
}
client_script {
	'vdkinv.lua',
	'GUI.lua'
}

export 'getQuantity'
export 'notFull'