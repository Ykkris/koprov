client_script {
  "gui.lua",
  "cl_pogarage.lua"
}
server_script "sv_pogarage.lua"
