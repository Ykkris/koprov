client_script "mazone_client.lua"
server_script "mazone_serveur.lua"