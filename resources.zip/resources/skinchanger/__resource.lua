client_scripts {
	'skinchanger.net.dll',
	'client/main.lua'
}

ui_page 'html/ui.html'

files {
	'html/ui.html',
	'html/bankgothic.ttf',
	'html/pdown.ttf',
	'html/img/keys/enter.png'
}