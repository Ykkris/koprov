client_script 'weashop.lua'
server_script 'sv_weashop.lua'

export 'ShowWeashopBlips'
