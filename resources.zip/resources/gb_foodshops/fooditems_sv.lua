fooditems = {
	{ ['name'] = "Sandwich", ['value'] = 20, ['type'] = 2, ['price'] = 200 },
	{ ['name'] = "Bouteille d'eau", ['value'] = 20, ['type'] = 1, ['price'] = 123 },
}
