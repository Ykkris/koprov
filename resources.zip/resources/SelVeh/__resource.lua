
server_scripts 'server.lua'

client_script 'client.lua'