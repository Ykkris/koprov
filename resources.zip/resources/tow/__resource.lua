-- Towtruck script by Asser90

-- Manifest
resource_manifest_version '77731fab-63ca-442c-a67b-abc70f28dfa5'

-- Requiring essentialmode
dependency 'essentialmode'

-- General
client_script 'cl_tow.lua'
server_script 'sv_tow.lua'